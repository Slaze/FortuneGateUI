# FortuneGate · UI screens & webflow

Self-contained client preview. All four pages cross-link.

## Files
- `index.html` — landing / overview
- `01-wireframes.html` — lo-fi flow map
- `02-prototype.html` — clickable mobile prototype (18 screens)
- `03-desktop.html` — admin shell + plans page

## To preview locally
Double-click `index.html`. Works offline, no server needed.

## To host on GitHub Pages
1. Create a new repo, e.g. `fortunegate-preview` (public or private — both work with Pages on free tier).
2. Drop these 4 files into the repo root.
3. Push to `main`.
4. Repo → **Settings → Pages**.
5. Source: **Deploy from a branch** → branch `main` → folder `/ (root)` → **Save**.
6. Wait ~30s. Public URL: `https://<you>.github.io/fortunegate-preview/`
7. Send to client.

### Alternative: drag-and-drop
Skip the repo. Go to **netlify.com/drop** or **vercel.com/new** → drag this folder in → instant URL with HTTPS + password protection (Netlify free tier).

## To embed in your Laravel app
Drop these files into `public/preview/` and link from `routes/web.php` or share `https://yoursite.com/preview/index.html`.
